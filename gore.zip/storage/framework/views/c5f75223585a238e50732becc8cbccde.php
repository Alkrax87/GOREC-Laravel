<?php $__env->startSection('title', 'Especialidad'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1><i class="fas fa-users-cog"></i> Especialidad</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-12">
          <!-- Agregar -->
          <div class="row">
            <div class="col-6">
              <button class="btn btn-success mb-4" data-toggle="modal" data-target="#ModalCreate"><i class="fas fa-plus"></i>&nbsp;&nbsp; Crear Especialidad</button>
            </div>
            <div class="col-3 offset-3 text-end">
                <form action="<?php echo e(route('especialidad.pdf')); ?>" method="GET" target="_blank">
                  
                    <label  class="form-label" style="text-align: left; display: block;">Inversión:</label>
                    <select name="idInversion" id="idInversion-especialidad" class="form-select form-select-sm input-auth" required>
                        <option value="" disabled selected>Selecciona una inversión</option>
                        <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($inversion->idInversion); ?>">
                                <?php echo e($inversion->nombreCortoInversion); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <br>
                    <br>
                   
                    <button type="submit" class="btn btn-dark"><i class="fas fa-print"></i>&nbsp;&nbsp; Imprimir</button>
                </form>
            </div>
          </div>
          <!-- Alert -->
          <?php if($message = Session::get('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <p class="alert-message mb-0"><i class="fas fa-check"></i>&nbsp;&nbsp; <?php echo e($message); ?></p>
            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible pb-0">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6><i class="icon fas fa-ban"></i> Error! Por favor corrige los errores en el formulario.</h6>
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>
          <?php if($errorPorcentaje = Session::get('errorPorcentaje')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <p class="alert-message mb-0"><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp; <?php echo e($errorPorcentaje); ?></p>
            </div>
          <?php endif; ?>
          <!-- Tabla -->
          <div class="table-responsive">
            <table id="especialidadTable" class="table table-bordered table-striped">
              <thead class="table-header">
                <tr>
                  <th class="text-left">#</th>
                  <th class="text-left">Inversión</th>
                  <th class="text-center">Nombre Especialidad</th>
                  <th class="text-center">Proyectistas</th>
                  <th class="text-center text-nowrap">Avance Programado</th>
                  <th class="text-center text-nowrap">Avance %</th>
                  <th class="text-center">Actividad</th>
                  <th class="text-center">Opciones</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-left"><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($especialidad->inversion->nombreCortoInversion); ?></td>
                    <td class="text-center text-nowrap"><?php echo e($especialidad->nombreEspecialidad); ?></td>
                    <td class="text-nowrap text-center">
                      <?php $__currentLoopData = $especialidad->usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <i class="fas fa-caret-right"></i> <?php echo e($usuario->nombreUsuario . ' ' . $usuario->apellidoUsuario); ?><br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="project_progress text-nowrap">
                      <div class="progress">
                        <div class="progress-bar progress-bar-striped bg-info" role="progressbar"
                          aria-valuenow="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                          aria-valuemin="0"
                          aria-valuemax="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                          style="width: <?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>%">
                        </div>
                      </div>
                      <div class="w-100 text-center">
                        <small><?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>% Especialidad</small>
                      </div>
                    </td>
                    <td class="project_progress text-nowrap">
                      <div class="progress">
                        <div class="progress-bar progress-bar-striped
                          <?php if($especialidad->avanceTotalEspecialidad < ($especialidad->porcentajeAvanceEspecialidad*0.25)): ?>
                              bg-danger
                          <?php elseif($especialidad->avanceTotalEspecialidad >= ($especialidad->porcentajeAvanceEspecialidad*0.25) && $especialidad->avanceTotalEspecialidad < ($especialidad->porcentajeAvanceEspecialidad*0.75)): ?>
                              bg-warning
                          <?php elseif($especialidad->avanceTotalEspecialidad >= ($especialidad->porcentajeAvanceEspecialidad*0.75) && $especialidad->avanceTotalEspecialidad < $especialidad->porcentajeAvanceEspecialidad): ?>
                              bg-success
                          <?php else: ?>
                              bg-info
                          <?php endif; ?>"
                          role="progressbar"
                          aria-valuenow="<?php echo e($especialidad->avanceTotalEspecialidad); ?>"
                          aria-valuemin="0"
                          aria-valuemax="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                          style="width: <?php echo e($especialidad->avanceTotalEspecialidad); ?>%">
                        </div>
                      </div>
                      <div class="w-100 text-center">
                        <small><?php echo e($especialidad->avanceTotalEspecialidad); ?>% Completado</small>
                      </div>
                    </td>
                    <td class="text-center text-nowrap">
                      <a class="btn bg-olive color-palette" data-toggle="modal" data-target="#ModalFase<?php echo e($especialidad->idEspecialidad); ?>"><i class="fas fa-briefcase"></i> Actividades</a>
                    </td>
                    <td class="text-center" style="white-space: nowrap"">
                      <a class="btn btn-info btn-option" data-toggle="modal" data-target="#ModalShow<?php echo e($especialidad->idEspecialidad); ?>"><i class="fas fa-eye"></i></a>
                      <?php if(Auth::user()->isAdmin || Auth::user()->idUsuario == $especialidad->inversion->idUsuario): ?>
                        <a class="btn btn-warning btn-option" data-toggle="modal" data-target="#ModalEditEspecialidad<?php echo e($especialidad->idEspecialidad); ?>"><i class="fas fa-edit"></i></a>
                        <a class="btn btn-danger btn-option" data-toggle="modal" data-target="#ModalDeleteEspecialidad<?php echo e($especialidad->idEspecialidad); ?>"><i class="fas fa-trash-alt"></i></a>
                      <?php endif; ?>
                      </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo $__env->make('especialidad.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('especialidad.fase.index', [
          'especialidad' => $especialidad,
          'fases' => $fases->where('idEspecialidad', $especialidad->idEspecialidad),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('especialidad.show', [
          'especialidad' => $especialidad,
          'fases' => $fases->where('idEspecialidad', $especialidad->idEspecialidad),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('especialidad.delete', ['especialidad' => $especialidad], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('especialidad.edit', ['especialidad' => $especialidad], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
  <li class="nav-item dropdown">
    <a class="nav-link" data-toggle="dropdown" aria-expanded="false">
      <i class="fas fa-bell"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge badge-danger ml-3 navbar-badge"> <?php echo e(count($notificaciones)); ?></span>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px; min-width: 600px;">
      <spa style="background-color: #9C0C27; color: azure;" class="dropdown-item dropdown-header text-center"><i class="fas fa-bell"></i> <?php echo e(count($notificaciones)); ?> Notificationes</spa>
      <div class="dropdown-divider"></div>
      <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dropdown-item">
          <span><i class="fas fa-clipboard-list"></i>&nbsp; <b>INVERSIÓN</b></span>
          <p><?php echo e($notificacion->nombreCortoInversion); ?> esta por finalizar.</p>
          <p class="pt-2 text-end"><i class="fas fa-calendar-alt"></i> Fecha de finalización: <?php echo e($notificacion->fechaFinalInversion); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="dropdown-divider"></div>
    </div>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.2/css/responsive.bootstrap5.css">
  <style>
    a {
      text-decoration: none;
    }
    .btn-option{
      height: 38px;
    }
    .btn-option i{
      padding-top: 4px;
    }
    .select2-container .select2-selection--single {
    text-align: left;
}
  </style>
  <!--estilos para los select2-->
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/dataTables.responsive.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/responsive.bootstrap5.min.js"></script>
  <script>
    $(document).ready(function() {
        $('#idInversion-especialidad').select2({
          placeholder: "Selecciona una inversion",
          allowClear: true,
          width: '100%', 
            language: {
              noResults: function() {
                return "No se encontró la inversión";
              }
            }
        });
      });
  </script>
  <script>
    $(document).ready(function() {
      $('#especialidadTable').DataTable({
        responsive: true,
        language: {
          search: "Buscar:",
          lengthMenu: "Mostrar _MENU_ registros por página",
          zeroRecords: "No se encontraron resultados",
          info: "Mostrando página _PAGE_ de _PAGES_",
          infoEmpty: "No hay registros disponibles",
          infoFiltered: "(filtrado de _MAX_ registros totales)",
          paginate: {
            first: "Primero",
            last: "Último",
            next: "Siguiente",
            previous: "Anterior"
          }
        }
      });
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/especialidad/index.blade.php ENDPATH**/ ?>