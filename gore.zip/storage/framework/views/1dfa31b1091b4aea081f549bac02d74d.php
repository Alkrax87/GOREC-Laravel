<!-- Modal -->
<form action="<?php echo e(route('password.update')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="modal fade text-left" id="ModalCreatepass">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><i class="fas fa-users"></i> Crear Usuario</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <div class="modal-body">
                    <div class="form-outline mb-4">
                        <label class="form-label">Nueva Contraseña</label>
                        <input type="password" name="new_password" class="form-control" required/>
                      </div>
                      <div class="form-outline mb-4">
                        <label class="form-label">Confirmar Contraseña</label>
                        <input type="password" name="new_password_confirmation" class="form-control" required/>
                      </div>
                      <div class="text-center">
                        <button type="submit" class="btn btn-primary">Cambiar Contraseña</button>
                      </div>
                </div>
            </div>
        </div>
    </div>
</form>



  
  <!-- Botón para abrir el modal --><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/password_change.blade.php ENDPATH**/ ?>