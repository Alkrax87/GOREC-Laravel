<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1>Home</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <h1>Listado de Proyectos</h1>
  <a href="<?php echo e(route('avanzeProyecto.create')); ?>" class="btn btn-primary mb-2">Crear Nuevo Proyecto</a>
  <table>
    <thead>
        <tr>
            <th>Proyecto</th>
            <th>Especialidad</th>
            <th>Fase</th>
            <th>Subfase</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $proyecto->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $especialidad->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $fase->subfases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($proyecto->nombreProyecto); ?></td>
            <td><?php echo e($especialidad->nombreEspecialidad); ?></td>
            <td><?php echo e($fase->nombreFase); ?></td>
            <td><?php echo e($subfase->nombreSubfase); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/avanzeProyecto/index.blade.php ENDPATH**/ ?>