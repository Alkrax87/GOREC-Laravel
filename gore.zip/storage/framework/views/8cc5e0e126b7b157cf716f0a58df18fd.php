<form action="<?php echo e(route('roles.update', $usuario->idUsuario)); ?>" method="POST">
  <?php echo e(method_field('patch')); ?>

  <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="ModalAdmin<?php echo e($usuario->idUsuario); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><i class="fas fa-users"></i>
            <?php if($usuario->isAdmin): ?>
              Eliminar privilegios de administrador
            <?php else: ?>
              Convertir en Usuario Administrador
            <?php endif; ?>
          </h4>
          <button onclick="window.location.href = '<?php echo e(route('roles.index')); ?>'" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center">
          <?php if($usuario->isAdmin): ?>
            ¿Estás seguro que deseas eliminar los privilegios de administrador al usuario <b><?php echo e($usuario->nombreUsuario . ' ' . $usuario->apellidoUsuario); ?></b>?
          <?php else: ?>
            ¿Estás seguro que deseas convertir al usuario <b><?php echo e($usuario->nombreUsuario . ' ' . $usuario->apellidoUsuario); ?></b> en administrador?
          <?php endif; ?>
          <div class="row">
            <div class="col-12 pt-3 text-center">
              <button onclick="window.location.href = '<?php echo e(route('roles.index')); ?>'" class="btn btn-primary mx-1" data-dismiss="modal"><i class="fas fa-undo-alt"></i>&nbsp;&nbsp; Volver</button>
              <button type="submit" class="btn btn-success mx-1"><i class="fas fa-user-shield"></i>&nbsp;&nbsp; Aceptar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/roles/change.blade.php ENDPATH**/ ?>