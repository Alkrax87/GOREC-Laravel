<form action="<?php echo e(route('inversion.show', $inversion->idInversion)); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <div class="modal fade text-left" id="ModalShow<?php echo e($inversion->idInversion); ?>">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><i class="fas fa-clipboard-list"></i> Detalle Inversión</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-12 py-2">
              <b><i class="fas fa-tag"></i> CUI:</b>&nbsp; <?php echo e($inversion->cuiInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-file-signature"></i> Nombre:</b>&nbsp; <?php echo e($inversion->nombreInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-file-signature"></i> Nombre Corto:</b>&nbsp; <?php echo e($inversion->nombreCortoInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-portrait"></i> Responsable:</b>&nbsp; <?php echo e(strtoupper($inversion->usuario->nombreUsuario . ' ' . $inversion->usuario->apellidoUsuario)); ?>

              ( P: 
              <?php if($inversion->usuario->profesiones->isNotEmpty()): ?>
                  <?php $__currentLoopData = $inversion->usuario->profesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($profesion->nombreProfesion); ?>

                    <?php if(!$loop->last): ?>
                        ,
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              )
              &nbsp; | &nbsp;
              ( E: 
              <?php if($inversion->usuario->especialidades->isNotEmpty()): ?>
                  <?php $__currentLoopData = $inversion->usuario->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($especialidad->nombreEspecialidad); ?>

                    <?php if(!$loop->last): ?>
                        ,
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              )
            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-map-marker-alt"></i> Provincia:</b>&nbsp; <?php echo e($inversion->provinciaInversion); ?>

            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-map-marker-alt"></i> Distrito:</b>&nbsp; <?php echo e($inversion->distritoInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-layer-group"></i> Nivel:</b>&nbsp; <?php echo e($inversion->nivelInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-cogs"></i> Función:</b>&nbsp; <?php echo e($inversion->funcionInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-stream"></i> Modalidad:</b>&nbsp; <?php echo e($inversion->modalidadInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-info"></i> Estado:</b>&nbsp; <?php echo e($inversion->estadoInversion); ?>

            </div>
            <div class="col-12 py-2">
              <b><i class="fas fa-percentage"></i> Avance:</b>&nbsp; <?php echo e($inversion->avanceInversion); ?>%
            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-calendar-alt"></i> Fecha Inicio:</b>&nbsp; <?php echo e($inversion->fechaInicioInversion); ?>

            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-calendar-alt"></i> Fecha Final:</b>&nbsp; <?php echo e($inversion->fechaFinalInversion); ?>

            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-file-invoice-dollar"></i> Formulación:</b>&nbsp; <?php echo e('s/ ' . number_format($inversion->presupuestoFormulacionInversion, 2, '.', ',')); ?>

            </div>
            <div class="col-6 py-2">
              <b><i class="fas fa-file-invoice-dollar"></i> Ejecución:</b>&nbsp; <?php echo e('s/ ' . number_format($inversion->presupuestoEjecucionInversion, 2, '.', ',')); ?>

            </div>
            <div class="col-12 mt-4 text-center">
              <button class="btn btn-primary" data-dismiss="modal"><i class="fas fa-undo-alt"></i>&nbsp;&nbsp; Volver</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/inversion/show.blade.php ENDPATH**/ ?>