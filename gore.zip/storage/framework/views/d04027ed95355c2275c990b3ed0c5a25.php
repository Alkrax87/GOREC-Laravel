<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        @page {
            margin: 140px 30px 100px 30px; /* Espacio para encabezado y pie de página */
        }
        header {
            position: fixed;
            top: -120px;
            left: 0;
            right: 0;
            height: 100px;
            text-align: center;
        }
        footer {
            position: fixed;
            bottom: -90px; /* Ajustar la posición del footer */
            left: 0;
            right: 0;
            height: 50px;
            text-align: center;
        }
        .footer-content {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .footer-image {
            width: 680px;
            height: 80px;
        }
        .date-time {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(15, 15, 15, 0.863); /* Ajusta este color según el fondo de la imagen */
            font-weight: bold;
            font-size: 12px;
            text-shadow: 1px 1px 2px #000; /* Sombra para mejorar la legibilidad */
        }
        .date-time .time {
        margin-left: 50px; /* Ajusta el valor para controlar la distancia */
        }

        .logo {
            display: flex;
            align-items: center;
        }
        .header img {
            width: 720px;
            height: 70px;
        }

        .logo img {
            margin-right: 5px; /* Espacio entre la imagen y el texto */
        }
        .container {
            width: 100%;
            margin: 0 auto;
        }
        .especialidad {
            margin-bottom: 10px;
            border: 3px solid #756d6d;
            padding: 10px;
            border-radius: 5px;
        }
        .especialidad p, ul, {
            margin-bottom: 6px;
            margin-top: 1px
           
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #a33030;
        }
        th {
            background-color: #b41919;
        }
        .table-container {
            margin-bottom: 20px;
        }
        .sub-table {
            margin-top: 10px;
            width: 100%;
        }
        h3 {
            text-align: center;
        }
        #table-container th {
            background-color: #991818;
            color: #fff;
            font-size: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <div class="header">
            <img src="images/banner-cuscofin.jpg" alt="Logo">
        </div>
    </header>
    <footer>
        <div class="footer-content">
            <img src="images/footter.jpg" style="width: 680px; height: 80px" alt="Logo">
            <div class="date-time">
                <p>Fecha: <?php echo e(date('d/m/Y')); ?> <span class="time">Hora: <?php echo e(date('H:i:s')); ?></span></p>
            </div>
        </div>
    </footer>
    
    <h3 style="text-align: center; margin: -5%">PROYECTO DE INVERSION</h3>
    <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><strong><?php echo e($inversion->nombreInversion); ?></strong></h3>
        <p class="text-nowrap"><span style="font-size: 20px;">Responsable:</span> <b><?php echo e(strtoupper($inversion->usuario->nombreUsuario . ' ' . $inversion->usuario->apellidoUsuario)); ?></b></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="container">
        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="especialidad">
                <p style="font-size: 20px;">Especialidad:  <b><?php echo e($especialidad->nombreEspecialidad); ?></b></p>
                <p><b>Avance Programado:</b> <?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>% &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span><b>Avance Total:</b> <?php echo e($especialidad->avanceTotalEspecialidad); ?>%</span></p>
                <p>Proyectistas:</p>
                <?php $__currentLoopData = $especialidad->usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="mb-0"><li><?php echo e($usuario->nombreUsuario . ' ' . $usuario->apellidoUsuario); ?> <span style="font-size: 11px"> (P: <?php echo e($usuario->profesiones->pluck('nombreProfesion')->implode(', ')); ?>) |
                    (E: <?php echo e($usuario->especialidades->pluck('nombreEspecialidad')->implode(', ')); ?>)</span>  </li></ul>
                
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($especialidad->fases && $especialidad->fases->count() > 0): ?>
                    <?php $__currentLoopData = $especialidad->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="table-container">
                            <table id="table-container">
                                <thead>
                                    <tr>
                                        <th>Actividad</th>
                                        <th>Avance Programado</th>
                                        <th>Avance (%)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($fase->nombreFase); ?></td>
                                        <td><?php echo e($fase->porcentajeAvanceFase); ?></td>
                                        <td><?php echo e($fase->avanceTotalFase); ?></td>
                                    </tr>
                                    <?php if($fase->subfases && $fase->subfases->count() > 0): ?>
                                        <tr>
                                            <td colspan="3">
                                                <div class="table-container sub-table">
                                                    <table>
                                                        <thead>
                                                            <tr>
                                                                <th>Sub Actividad</th>
                                                                <th>Fecha Inicio</th>
                                                                <th>Fecha Final</th>
                                                                <th>Avance Programado</th>
                                                                <th>Avance (%)</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $fase->subfases->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($subfase->nombreSubfase); ?></td>
                                                                    <td><?php echo e($subfase->fechaInicioSubfase); ?></td>
                                                                    <td><?php echo e($subfase->fechaFinalSubfase); ?></td>
                                                                    <td><?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?></td>
                                                                    <td><?php echo e($subfase->avanceRealTotalSubFase); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="3">No hay subfases disponibles.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>No hay fases disponibles.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/especialidad/pdf.blade.php ENDPATH**/ ?>