<form action="<?php echo e(route('profesional.destroy', $profesional->idUsuario)); ?>" method="POST">
  <?php echo e(method_field('delete')); ?>

  <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="ModalDelete<?php echo e($inversion->idInversion . '-' . $profesional->idUsuario); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><i class="fas fa-user-tie"></i> Eliminar Profesional</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <input type="hidden" value="<?php echo e($inversion->idInversion); ?>" name="idInversion" class="input-auth" required/>
        <input type="hidden" value="<?php echo e($profesional->idUsuario); ?>" name="idUsuario" class="input-auth" required/>
        <div class="modal-body text-center">
          ¿Estas seguro que deseas borrar a <b><?php echo e($profesional->usuario->nombreUsuario . ' ' . $profesional->usuario->apellidoUsuario); ?></b> de la lista de profesionales?
          <div class="row">
            <div class="col-12 pt-3 text-center">
              <button class="btn btn-primary mx-1" data-dismiss="modal"><i class="fas fa-undo-alt"></i>&nbsp;&nbsp; Volver</button>
              <button type="submit" class="btn btn-danger mx-1"><i class="fas fa-trash-alt"></i>&nbsp;&nbsp; Eliminar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/asignaciones/profesional/delete.blade.php ENDPATH**/ ?>