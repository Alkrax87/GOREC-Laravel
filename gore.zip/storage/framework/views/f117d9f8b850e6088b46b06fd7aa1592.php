<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        @page {
            margin: 140px 30px 100px 30px; /* Espacio para encabezado y pie de página */
        }
        header {
            position: fixed;
            top: -120px;
            left: 0;
            right: 0;
            height: 100px;
            text-align: center;
        }
        footer {
            position: fixed;
            bottom: -90px; /* Ajustar la posición del footer */
            left: 0;
            right: 0;
            height: 50px;
            text-align: center;
        }
        .footer-content {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .footer-image {
            width: 680px;
            height: 80px;
        }
        .date-time {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(15, 15, 15, 0.863); /* Ajusta este color según el fondo de la imagen */
            font-weight: bold;
            font-size: 12px;
            text-shadow: 1px 1px 2px #000; /* Sombra para mejorar la legibilidad */
        }
        .date-time .time {
        margin-left: 50px; /* Ajusta el valor para controlar la distancia */
        }
        .content {
            margin-top: 40px;
        }
        .header img {
            width: 720px;
            height: 70px;
        }
        .table-container {
            width: 98%;
            max-width: 800px;
            margin: 0 auto;
            border-collapse: collapse;
        }
        .table-container th, .table-container td {
            padding: 10px;
            font-size: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .table-container th {
            background-color: #991818;
            color: #fff;
            font-size: 12px;
            font-weight: bold;
        }
        .table-container tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <header>
        <div class="header">
            <img src="images/banner-cuscofin.jpg" alt="Logo">
        </div>
    </header>
    <footer>
        <div class="footer-content">
            <img src="images/footter.jpg" style="width: 680px; height: 80px" alt="Logo">
            <div class="date-time">
                <p>Fecha: <?php echo e(date('d/m/Y')); ?> <span class="time">Hora: <?php echo e(date('H:i:s')); ?></span></p>
            </div>
        </div>
    </footer>
   <h3 style="text-align: center; margin: -5%">PROYECTO DE INVERSION</h3>
    <div class="content">
    <table class="table-container">
        <tr>
            <th>CUI</th>
            <td><?php echo e($inversion->cuiInversion); ?></td>
        </tr>
        <tr>
            <th>Nombre</th>
            <td colspan="3"><strong><?php echo e($inversion->nombreInversion); ?></strong></td>
            
        </tr>
        <tr>
            <th>Nombre Corto</th>
            <td colspan="3"><?php echo e($inversion->nombreCortoInversion); ?></td>
        </tr>
        <tr>
            <th>Responsable</th>
            <td colspan="3">
            <b><?php echo e(strtoupper($inversion->usuario->nombreUsuario . ' ' . $inversion->usuario->apellidoUsuario)); ?></b>
            <span style="font-size: 10px">( P: 
                <?php if($inversion->usuario->profesiones->isNotEmpty()): ?>
                    <?php $__currentLoopData = $inversion->usuario->profesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($profesion->nombreProfesion); ?>

                        <?php if(!$loop->last): ?>
                            ,
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                )
                &nbsp; | &nbsp;
                ( E: 
                <?php if($inversion->usuario->especialidades->isNotEmpty()): ?>
                    <?php $__currentLoopData = $inversion->usuario->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($especialidad->nombreEspecialidad); ?>

                        <?php if(!$loop->last): ?>
                            ,
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                )</span>
            </td>
        </tr>
       <!-- Mostrar profesionales y asistentes -->
       <tr>
        <th>Profesionales y Asistentes</th>
        <td colspan="3">
            <strong>Profesionales:</strong><br><br><!-- Título para Profesionales -->
            <?php $__currentLoopData = $inversion->profesional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <strong><?php echo e($asignacion->usuario->nombreUsuario); ?> <?php echo e($asignacion->usuario->apellidoUsuario); ?></strong>&nbsp; 
                <span style="font-size: 10px">(P: <?php echo e($asignacion->usuario->profesiones->pluck('nombreProfesion')->implode(', ')); ?>) |
                    (E: <?php echo e($asignacion->usuario->especialidades->pluck('nombreEspecialidad')->implode(', ')); ?>) </span>
                <ul style="list-style: none">
                    <strong>Asistentes:</strong> 
                    <?php $__currentLoopData = $inversion->asistente->where('idJefe', $asignacion->usuario->idUsuario); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistenteAsignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>- &nbsp; <?php echo e($asistenteAsignacion->usuario->nombreUsuario); ?> <?php echo e($asistenteAsignacion->usuario->apellidoUsuario); ?> &nbsp; 
                            <span style="font-size: 10px"> (P: <?php echo e($asistenteAsignacion->usuario->profesiones->pluck('nombreProfesion')->implode(', ')); ?>) |
                                (E: <?php echo e($asistenteAsignacion->usuario->especialidades->pluck('nombreEspecialidad')->implode(', ')); ?>) </span>  </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>


        <tr>
            <th>Provincia</th>
            <td><?php echo e($inversion->provinciaInversion); ?></td>
            <th>Distrito</th>
            <td><?php echo e($inversion->distritoInversion); ?></td>
        </tr>
        <tr>
            <th>Nivel</th>
            <td colspan="3"><?php echo e($inversion->nivelInversion); ?></td>
        </tr>
        <tr>
            <th>Función</th>
            <td colspan="3"><?php echo e($inversion->funcionInversion); ?></td>
        </tr>
        <tr>
            <th>Modalidad</th>
            <td colspan="3"><?php echo e($inversion->modalidadInversion); ?></td>
        </tr>
        <tr>
            <th>Estado</th>
            <td colspan="3"><?php echo e($inversion->estadoInversion); ?></td>
        </tr>
        <tr>
            <th>Avance</th>
            <td colspan="3" style="font-size: 15px"><b><?php echo e($inversion->avanceInversion); ?>%</b></td>
        </tr>
        <tr>
            <th>Fecha Inicio</th>
            <td colspan="3"><?php echo e($inversion->fechaInicioInversion); ?></td>
        </tr>
        <tr>
            <th>Fecha Final</th>
            <td colspan="3"><?php echo e($inversion->fechaFinalInversion); ?></td>
        </tr>
        <tr>
            <th>Formulación</th>
            <td colspan="3"><?php echo e('s/ ' . number_format($inversion->presupuestoFormulacionInversion, 2, '.', ',')); ?></td>
        </tr>
        <tr>
            <th>Ejecución</th>
            <td colspan="3"><?php echo e('s/ ' . number_format($inversion->presupuestoEjecucionInversion, 2, '.', ',')); ?></td>
        </tr>
        <tr>
            <th>Fecha Inicio Consistencia</th>
            <td colspan="3"><?php echo e($inversion->fechaInicioConsistenciaInversion); ?></td>
        </tr>
        <tr>
            <th>Fecha Final Consistencia</th>
            <td colspan="3"><?php echo e($inversion->fechaFinalConsistenciaInversion); ?></td>
        </tr>
       
    </table>
   
</div>

</body>
</html>





<?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/inversion/pdf.blade.php ENDPATH**/ ?>