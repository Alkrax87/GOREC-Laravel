<?php $__env->startSection('title', 'Asignaciones'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1><i class="fas fa-user-tag"></i> Asignaciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-12">
          <!-- Alert -->
          <?php if($message = Session::get('profesional_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <p class="alert-message mb-0"><i class="fas fa-check-circle"></i>&nbsp;&nbsp; <?php echo e($message); ?></p>
          </div>
          <?php endif; ?>
          <?php if($error = Session::get('error')): ?>
                 <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <p class="alert-message mb-0"><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp; <?php echo e($error); ?></p>
                </div>
          <?php endif; ?>
          <?php if($error = Session::get('error_asistente')): ?>
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <p class="alert-message mb-0"><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp; <?php echo e($error); ?></p>
            </div>
          <?php endif; ?>

          <?php if($message = Session::get('asistente_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <p class="alert-message mb-0"><i class="fas fa-check-circle"></i>&nbsp;&nbsp; <?php echo e($message); ?></p>
          </div>
          <?php endif; ?>
          <!-- Tabla -->
          <div class="table-responsive">
            <table id="asignacionesTable" class="table table-bordered table-striped w-100">
              <thead class="table-header">
                <tr>
                  <th>#</th>
                  <th class="text-nowrap">CUI</th>
                  <th class="text-nowrap">Inversión</th>
                  <th class="text-nowrap">Nombre Corto</th>
                  <th class="text-center">Provincia</th>
                  <th class="text-center">Distrito</th>
                  <th class="text-center">Modalidad</th>
                  <th class="text-center">Estado</th>
                  <th class="text-center">Opciones</th>
                  <?php if(Auth::user()->isAdmin): ?>
                    <th class="text-center">Profesional</th>
                    <th class="text-center">Asistente</th>
                  <?php endif; ?>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                    <td class="text-center text-nowrap"><?php echo e($inversion->cuiInversion); ?></td>
                    <td><?php echo e($inversion->nombreInversion); ?></td>
                    <td><?php echo e($inversion->nombreCortoInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->provinciaInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->distritoInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->modalidadInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->estadoInversion); ?></td>
                    <td class="text-center" style="white-space: nowrap">
                      <a class="btn btn-info btn-option" data-toggle="modal" data-target="#ModalShow<?php echo e($inversion->idInversion); ?>"><i class="fas fa-eye"></i></a>
                    </td>
                    <?php if(Auth::user()->isAdmin): ?>
                      <td class="text-center" style="white-space: nowrap">
                        <a class="btn btn-success" data-toggle="modal" data-target="#ModalProfesional<?php echo e($inversion->idInversion); ?>"><i class="fas fa-user-tie"></i> Profesionales</a>
                      </td>
                      <td class="text-center" style="white-space: nowrap">
                        <a class="btn btn-dark" data-toggle="modal" data-target="#ModalAsistentes<?php echo e($inversion->idInversion); ?>"><i class="fas fa-users-cog"></i> Asistentes</a>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('asignaciones.profesional.index', [
          'inversion' => $inversion,
          'profesionales' => $profesionales->where('idInversion', $inversion->idInversion)
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('asignaciones.asistente.index', [
          'inversion' => $inversion,
          'asistentes' => $asistentes->where('idInversion', $inversion->idInversion),
          'profesionales' => $profesionales->where('idInversion', $inversion->idInversion)
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('asignaciones.show', [
          'inversion' => $inversion,
          'profesionales' => $profesionales->where('idInversion', $inversion->idInversion),
          'asistentes' => $asistentes->where('idInversion', $inversion->idInversion)
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
  <li class="nav-item dropdown">
    <a class="nav-link" data-toggle="dropdown" aria-expanded="false">
      <i class="fas fa-bell"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge badge-danger ml-3 navbar-badge"> <?php echo e(count($notificaciones)); ?></span>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px; min-width: 600px;">
      <spa style="background-color: #9C0C27; color: azure;" class="dropdown-item dropdown-header text-center"><i class="fas fa-bell"></i> <?php echo e(count($notificaciones)); ?> Notificationes</spa>
      <div class="dropdown-divider"></div>
      <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dropdown-item">
          <span><i class="fas fa-clipboard-list"></i>&nbsp; <b>INVERSIÓN</b></span>
          <p><?php echo e($notificacion->nombreCortoInversion); ?> esta por finalizar.</p>
          <p class="pt-2 text-end"><i class="fas fa-calendar-alt"></i> Fecha de finalización: <?php echo e($notificacion->fechaFinalInversion); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="dropdown-divider"></div>
    </div>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.2/css/responsive.bootstrap5.css">
  <style>
    a {
      text-decoration: none;
    }
    .btn-option{
      height: 38px;
    }
    .btn-option i{
      padding-top: 4px;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/dataTables.responsive.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/responsive.bootstrap5.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#asignacionesTable').DataTable({
        responsive: true,
        language: {
          search: "Buscar:",
          lengthMenu: "Mostrar _MENU_ registros por página",
          zeroRecords: "No se encontraron resultados",
          info: "Mostrando página _PAGE_ de _PAGES_",
          infoEmpty: "No hay registros disponibles",
          infoFiltered: "(filtrado de _MAX_ registros totales)",
          paginate: {
            first: "Primero",
            last: "Último",
            next: "Siguiente",
            previous: "Anterior"
          }
        }
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<style>
  body {
    background-color: #000;
  }
  section {
    margin-top: 100px;
  }
  /* Others */
  .center-items {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  /* Card Style */
  .cascading-left {
    margin-left: -50px;
  }
  /* Input Style  */
  .input-auth {
    display: block;
    width: 100%;
    height: calc(1.5em + 0.75rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: all 0.3s ease-in-out;
  }
  .input-auth:focus {
    border-color: #72081f;
    outline: none;
    box-shadow: 0 0 5px 2px rgba(255, 106, 133, 0.5);
  }
  .input-autht:focus::placeholder {
    color: transparent;
  }
  /* Btn Style  */
  .btn-gorec {
    width: 250px;
    height: 50px;
    background-color: #9C0C27;
    color: #fff;
    border-radius: 50px
  }
  .btn-gorec:hover {
    background-color: #72081f;
    color: #fff;;
  }
  /* Line */
  .line {
    border: 0;
    border-top: 1px solid #72081f;
    margin: 1rem 0;
    width: 50%;
  }
  /* Redirection */
  .login-direction {
    color: #72081f;
    text-decoration: none;
  }
  @media (max-width: 991.98px) {
    .cascading-left {
      margin-left: 0px;
    }
    section {
      margin-top: 0px;
    }
  }
</style>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/asignaciones/index.blade.php ENDPATH**/ ?>