<div class="modal fade text-left" id="ModalLog<?php echo e($inversion->idInversion); ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><i class="fas fa-clipboard-list"></i> Registro de cambios estado</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3><?php echo e($inversion->nombreCortoInversion); ?></h3>
        <div class="container-fluid px-0 pt-3">
          <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
              <div class="card-header">
                <b><i class="fas fa-calendar-alt"></i> Fecha:</b>&nbsp; <?php echo e($log->fechaCambioEstado); ?>

              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-6">
                    <b><i class="fas fa-info"></i> Estado Anterior:</b>&nbsp; <?php echo e($log->estadoInversionOLD); ?>

                  </div>
                  <div class="col-6">
                    <b><i class="fas fa-info"></i> Estado Cambiado:</b>&nbsp; <?php echo e($log->estadoInversionNEW); ?>

                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/inversion/estadoLog.blade.php ENDPATH**/ ?>