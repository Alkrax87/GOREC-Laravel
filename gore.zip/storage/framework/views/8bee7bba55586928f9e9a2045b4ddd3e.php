<div class="modal fade" id="ModalShow<?php echo e($especialidad->idEspecialidad); ?>">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><i class="fas fa-users-cog"></i> Detalle Especialidad</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h2><?php echo e($especialidad->nombreEspecialidad); ?></h2>
              <b>Proyectistas: </b>
              <?php $__currentLoopData = $especialidad->usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="mb-0"><i class="fas fa-portrait"></i> <?php echo e($usuario->nombreUsuario . ' ' . $usuario->apellidoUsuario); ?></p>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <div class="row mt-3">
                <div class="col-6">
                  <div class="project_progress text-nowrap">
                    <div class="w-100 text-center">
                      <h4>Avance programado</h4>
                    </div>
                    <div class="progress">
                      <div class="progress-bar progress-bar-striped bg-info" role="progressbar"
                        aria-valuenow="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                        aria-valuemin="0"
                        aria-valuemax="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                        style="width: <?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>%">
                      </div>
                    </div>
                    <div class="w-100 text-center">
                      <small><?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>% Especialidad</small>
                    </div>
                  </div>
                </div>
                <div class="col-6">
                  <div class="project_progress text-nowrap">
                    <div class="w-100 text-center">
                      <h4>Avance %</h4>
                    </div>
                    <div class="progress">
                      <div class="progress-bar progress-bar-striped
                        <?php if($especialidad->avanceTotalEspecialidad < ($especialidad->porcentajeAvanceEspecialidad*0.25)): ?>
                            bg-danger
                        <?php elseif($especialidad->avanceTotalEspecialidad >= ($especialidad->porcentajeAvanceEspecialidad*0.25) && $especialidad->avanceTotalEspecialidad < ($especialidad->porcentajeAvanceEspecialidad*0.75)): ?>
                            bg-warning
                        <?php elseif($especialidad->avanceTotalEspecialidad >= ($especialidad->porcentajeAvanceEspecialidad*0.75) && $especialidad->avanceTotalEspecialidad < $especialidad->porcentajeAvanceEspecialidad): ?>
                            bg-success
                        <?php else: ?>
                            bg-info
                        <?php endif; ?>"
                        role="progressbar"
                        aria-valuenow="<?php echo e($especialidad->avanceTotalEspecialidad); ?>"
                        aria-valuemin="0"
                        aria-valuemax="<?php echo e($especialidad->porcentajeAvanceEspecialidad); ?>"
                        style="width: <?php echo e($especialidad->avanceTotalEspecialidad); ?>%">
                      </div>
                    </div>
                    <div class="w-100 text-center">
                      <small><?php echo e($especialidad->avanceTotalEspecialidad); ?>% Completado</small>
                    </div>
                  </div>
                </div>
              </div>
              <h4 class="pt-3"><i class="fas fa-briefcase"></i> Actividades</h4>
              <?php $__currentLoopData = $especialidad->fases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-danger">
                  <div class="card-header bg-danger">
                    <b><i class="fas fa-briefcase"></i> <?php echo e($fase->nombreFase); ?></b>
                  </div>
                  <div class="card-body pb-0">
                    <div class="row">
                      <div class="col-6">
                        <div class="project_progress text-nowrap">
                          <div class="w-100 text-center">
                            <h5>Avance programado</h5>
                          </div>
                          <div class="progress">
                            <div class="progress-bar progress-bar-striped bg-info" role="progressbar"
                              aria-valuenow="<?php echo e($fase->porcentajeAvanceFase); ?>"
                              aria-valuemin="0"
                              aria-valuemax="<?php echo e($fase->porcentajeAvanceFase); ?>"
                              style="width: <?php echo e($fase->porcentajeAvanceFase); ?>%">
                            </div>
                          </div>
                          <div class="w-100 text-center">
                            <small><?php echo e($fase->porcentajeAvanceFase); ?>% Actividad</small>
                          </div>
                        </div>
                      </div>
                      <div class="col-6">
                        <div class="project_progress text-nowrap">
                          <div class="w-100 text-center">
                            <h5>Avance %</h5>
                          </div>
                          <div class="progress">
                            <div class="progress-bar progress-bar-striped
                              <?php if($fase->avanceTotalFase < ($fase->porcentajeAvanceFase*0.25)): ?>
                                  bg-danger
                              <?php elseif($fase->avanceTotalFase >= ($fase->porcentajeAvanceFase*0.25) && $fase->avanceTotalFase < ($fase->porcentajeAvanceFase*0.75)): ?>
                                  bg-warning
                              <?php elseif($fase->avanceTotalFase >= ($fase->porcentajeAvanceFase*0.75) && $fase->avanceTotalFase < $fase->porcentajeAvanceFase): ?>
                                  bg-success
                              <?php else: ?>
                                  bg-info
                              <?php endif; ?>"
                              role="progressbar"
                              aria-valuenow="<?php echo e($fase->avanceTotalFase); ?>"
                              aria-valuemin="0"
                              aria-valuemax="<?php echo e($fase->porcentajeAvanceFase); ?>"
                              style="width: <?php echo e($fase->avanceTotalFase); ?>%">
                            </div>
                          </div>
                          <div class="w-100 text-center">
                            <small><?php echo e($fase->avanceTotalFase); ?>% Completado</small>
                          </div>
                        </div>
                      </div>
                    </div>
                    <hr class="mt-0">
                    <h5><i class="fa fa-tasks"></i> Sub Actividades</h5>
                    <?php $__currentLoopData = $fase->subfases->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subfase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card text-white bg-dark mb-3">
                        <div class="card-header">
                          <div class="row">
                            <div class="col-6">
                              <i class="fa fa-tasks"></i> <?php echo e($subfase->nombreSubfase); ?>

                            </div>
                            <div class="col-6">
                              <div class="row">
                                <div class="col-6 text-right">
                                  <span ><i class="far fa-calendar-alt"></i>&nbsp;Inicio: <?php echo e($subfase->fechaInicioSubfase); ?></span>
                                </div>
                                <div class="col-6 text-right">
                                  <span ><i class="far fa-calendar-alt"></i>&nbsp;Final: <?php echo e($subfase->fechaFinalSubfase); ?></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="card-body">
                          <div class="row">
                            <p>Total de dias programados: <?php echo e($subfase->cantidadDiasSubFase); ?></p>
                            <div class="col-4">
                              <h5 class="text-center">Avance Programado</h5>
                              <div class="project_progress text-nowrap">
                                <div class="progress">
                                  <div class="progress-bar progress-bar-striped bg-info" role="progressbar"
                                    aria-valuenow="<?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?>"
                                    aria-valuemin="0"
                                    aria-valuemax="<?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?>"
                                    style="width: <?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?>%">
                                  </div>
                                </div>
                                <div class="w-100 text-center">
                                  <small><?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?>% Sub Actividad</small>
                                </div>
                              </div>
                            </div>
                            <div class="col-4">
                              <h5 class="text-center">Avance %</h5>
                              <div class="project_progress text-nowrap">
                                <div class="progress">
                                  <div class="progress-bar progress-bar-striped
                                    <?php if($subfase->avanceRealTotalSubFase < ($subfase->porcentajeAvanceProgramadoSubFase*0.25)): ?>
                                        bg-danger
                                    <?php elseif($subfase->avanceRealTotalSubFase >= ($subfase->porcentajeAvanceProgramadoSubFase*0.25) && $subfase->avanceRealTotalSubFase < ($subfase->porcentajeAvanceProgramadoSubFase*0.75)): ?>
                                        bg-warning
                                    <?php elseif($subfase->avanceRealTotalSubFase >= ($subfase->porcentajeAvanceProgramadoSubFase*0.75) && $subfase->avanceRealTotalSubFase < $subfase->porcentajeAvanceProgramadoSubFase): ?>
                                        bg-success
                                    <?php else: ?>
                                        bg-info
                                    <?php endif; ?>"
                                    role="progressbar"
                                    aria-valuenow="<?php echo e($subfase->avanceRealTotalSubFase); ?>"
                                    aria-valuemin="0"
                                    aria-valuemax="<?php echo e($subfase->porcentajeAvanceProgramadoSubFase); ?>"
                                    style="width: <?php echo e($subfase->avanceRealTotalSubFase); ?>%">
                                  </div>
                                </div>
                                <div class="w-100 text-center">
                                  <small><?php echo e($subfase->avanceRealTotalSubFase); ?>% Completado</small>
                                </div>
                              </div>
                            </div>
                            <div class="col-4">
                              <h5 class="text-center">Avance Usuario</h5>
                              <div class="project_progress text-nowrap">
                                <div class="progress">
                                  <div class="progress-bar progress-bar-striped
                                    <?php if($subfase->avance_por_usuario_realSubFase < 25): ?>
                                        bg-danger
                                    <?php elseif($subfase->avance_por_usuario_realSubFase >= 25 && $subfase->avance_por_usuario_realSubFase < 75): ?>
                                        bg-warning
                                    <?php elseif($subfase->avance_por_usuario_realSubFase >= 75 && $subfase->avance_por_usuario_realSubFase < 100): ?>
                                        bg-success
                                    <?php else: ?>
                                        bg-info
                                    <?php endif; ?>"
                                    role="progressbar"
                                    aria-valuenow="<?php echo e($subfase->avance_por_usuario_realSubFase); ?>"
                                    aria-valuemin="0"
                                    aria-valuemax="100"
                                    style="width: <?php echo e($subfase->avance_por_usuario_realSubFase); ?>%">
                                  </div>
                                </div>
                                <div class="w-100 text-center">
                                  <small><?php echo e($subfase->avance_por_usuario_realSubFase); ?>% Usuario</small>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/especialidad/show.blade.php ENDPATH**/ ?>