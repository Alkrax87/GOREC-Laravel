<?php $__env->startSection('title', 'Inversion'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1><i class="fas fa-clipboard-list"></i> Inversiones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-12">
          <!-- Agregar -->
          <div class="row">
            <?php if(Auth::user()->isAdmin): ?>
              <div class="col-6">
                <button class="btn btn-success mb-4" data-toggle="modal" data-target="#ModalCreate"><i class="fas fa-plus"></i>&nbsp;&nbsp; Agregar Inversión</button>
              </div>
              <div class="col-6 text-end">
                <a href="<?php echo e(route('inversion.pdfs')); ?>" class="btn btn-dark" target="_blank"><i class="fas fa-print"></i>&nbsp;&nbsp; Imprimir</a>
              </div>
            <?php endif; ?>
          </div>
          <!-- Alert -->
          <?php if($message = Session::get('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <p class="alert-message mb-0"><i class="fas fa-check"></i>&nbsp;&nbsp; <?php echo e($message); ?></p>
            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible pb-0">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h6><i class="icon fas fa-ban"></i> Error! Por favor corrige los errores en el formulario.</h6>
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endif; ?>
          <!-- Tabla -->
          <div class="table-responsive">
            <table id="segmentosTable" class="table table-bordered table-striped">
              <thead class="table-header">
                <tr>
                  <th>#</th>
                  <th class="text-nowrap">CUI</th>
                  <th class="text-nowrap" style="min-width: 400px">Nombre</th>
                  <th class="text-nowrap">Nombre Corto</th>
                  <th class="text-center">Responsable</th>
                  <th class="text-center">Avance</th>
                  <th class="text-center">Provincia</th>
                  <th class="text-center">Distrito</th>
                  <th class="text-center">Estado</th>
                  <th class="text-nowrap">Fecha Inicio</th>
                  <th class="text-nowrap">Fecha Final</th>
                  <th class="text-center">Nivel</th>
                  <th class="text-center">Función</th>
                  <th class="text-center">Modalidad</th>
                  <th class="text-nowrap">Presupuesto Formulación</th>
                  <th class="text-nowrap">Presupuesto Ejecución</th>
                  <th class="text-nowrap">Fecha Inicio Consistencia</th>
                  <th class="text-nowrap">Fecha Final Consistencia</th>
                  <th class="text-center">Extras</th>
                  <th class="text-center">Opciones</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-left"><?php echo e($loop->index + 1); ?></td>
                    <td class="text-nowrap"><?php echo e($inversion->cuiInversion); ?></td>
                    <td><?php echo e($inversion->nombreInversion); ?></td>
                    <td><?php echo e($inversion->nombreCortoInversion); ?></td>
                    <td class="text-nowrap text-center"><?php echo e($inversion->usuario->nombreUsuario . ' ' . $inversion->usuario->apellidoUsuario); ?></td>
                    <td class="project_progress text-nowrap">
                      <div class="progress">
                        <div class="progress-bar progress-bar-striped
                          <?php if($inversion->avanceInversion < 25): ?>
                              bg-danger
                          <?php elseif($inversion->avanceInversion >= 25 && $inversion->avanceInversion < 75): ?>
                              bg-warning
                          <?php elseif($inversion->avanceInversion >= 75 && $inversion->avanceInversion < 100): ?>
                              bg-success
                          <?php else: ?>
                              bg-info
                          <?php endif; ?>"
                          role="progressbar"
                          aria-valuenow="<?php echo e($inversion->avanceInversion); ?>"
                          aria-valuemin="0"
                          aria-valuemax="100"
                          style="width: <?php echo e($inversion->avanceInversion); ?>%">
                      </div>
                        </div>
                      </div>
                      <small><?php echo e($inversion->avanceInversion); ?>% Completado</small>
                    </td>
                    <td class="text-center"><?php echo e($inversion->provinciaInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->distritoInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->estadoInversion); ?></td>
                    <td class="text-center"><i class="fas fa-calendar-alt"></i>&nbsp; <?php echo e($inversion->fechaInicioInversion); ?></td>
                    <td class="text-center"><i class="fas fa-calendar-alt"></i>&nbsp; <?php echo e($inversion->fechaFinalInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->nivelInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->funcionInversion); ?></td>
                    <td class="text-center"><?php echo e($inversion->modalidadInversion); ?></td>
                    <td class="text-center"><?php echo e('s/ ' . number_format($inversion->presupuestoFormulacionInversion, 2, '.', ',')); ?></td>
                    <td class="text-center"><?php echo e('s/ ' . number_format($inversion->presupuestoEjecucionInversion, 2, '.', ',')); ?></td>
                    <td class="text-center">
                      <i class="fas fa-calendar-alt"></i>&nbsp;
                      <?php if(is_null($inversion->fechaInicioConsistenciaInversion)): ?>
                        Por Definir
                      <?php else: ?>
                        <?php echo e($inversion->fechaInicioConsistenciaInversion); ?>

                      <?php endif; ?>
                    </td>
                    <td class="text-center">
                      <i class="fas fa-calendar-alt"></i>&nbsp;
                      <?php if(is_null($inversion->fechaFinalConsistenciaInversion)): ?>
                        Por Definir
                      <?php else: ?>
                        <?php echo e($inversion->fechaFinalConsistenciaInversion); ?>

                      <?php endif; ?>
                    </td>
                    <td class="text-center text-nowrap">
                      <a class="btn btn-dark btn-option" href="<?php echo e(route('inversion.pdf', $inversion->idInversion)); ?>" target="_blank"><i class="fas fa-print"></i></a>
                      <?php if(Auth::user()->isAdmin): ?>
                        <a class="btn btn-secondary btn-option" data-toggle="modal" data-target="#ModalLog<?php echo e($inversion->idInversion); ?>"><i class="fas fa-list"></i></a>
                      <?php endif; ?>
                    </td>
                    <td class="text-center text-nowrap">
                      <a class="btn btn-info btn-option" data-toggle="modal" data-target="#ModalShow<?php echo e($inversion->idInversion); ?>"><i class="fas fa-eye"></i></a>
                      <?php if(Auth::user()->isAdmin || Auth::user()->idUsuario == $inversion->idUsuario): ?>
                        <a class="btn btn-warning btn-option" data-toggle="modal" data-target="#ModalEdit<?php echo e($inversion->idInversion); ?>"><i class="fas fa-edit"></i></a>
                      <?php endif; ?>
                      <?php if(Auth::user()->isAdmin): ?>
                        <a class="btn btn-danger btn-option" data-toggle="modal" data-target="#ModalDelete<?php echo e($inversion->idInversion); ?>"><i class="fas fa-trash-alt"></i></a>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo $__env->make('inversion.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inversion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('inversion.delete', ['inversion' => $inversion], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inversion.edit', ['inversion' => $inversion], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inversion.show', ['inversion' => $inversion], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inversion.estadoLog', [
          'inversion' => $inversion,
          'logs' => $logs->where('idInversion', $inversion->idInversion),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
  <li class="nav-item dropdown">
    <a class="nav-link" data-toggle="dropdown" aria-expanded="false">
      <i class="fas fa-bell"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge badge-danger ml-3 navbar-badge"> <?php echo e(count($notificaciones)); ?></span>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="left: inherit; right: 0px; min-width: 600px;">
      <spa style="background-color: #9C0C27; color: azure;" class="dropdown-item dropdown-header text-center"><i class="fas fa-bell"></i> <?php echo e(count($notificaciones)); ?> Notificationes</spa>
      <div class="dropdown-divider"></div>
      <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dropdown-item">
          <span><i class="fas fa-clipboard-list"></i>&nbsp; <b>INVERSIÓN</b></span>
          <p><?php echo e($notificacion->nombreCortoInversion); ?> esta por finalizar.</p>
          <p class="pt-2 text-end"><i class="fas fa-calendar-alt"></i> Fecha de finalización: <?php echo e($notificacion->fechaFinalInversion); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="dropdown-divider"></div>
    </div>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap5.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.2/css/responsive.bootstrap5.css">
  <style>
    a {
      text-decoration: none;
    }
    .btn-option{
      height: 38px;
    }
    .btn-option i{
      padding-top: 4px;
    }
  </style>
  <style>
    body {
      background-color: #000;
    }
    section {
      margin-top: 100px;
    }
    /* Others */
    .center-items {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    /* Card Style */
    .cascading-left {
      margin-left: -50px;
    }
    /* Input Style  */
    .input-auth {
      display: block;
      width: 100%;
      height: calc(1.5em + 0.75rem + 2px);
      padding: 0.375rem 0.75rem;
      font-size: 1rem;
      font-weight: 400;
      line-height: 1.5;
      color: #495057;
      background-color: #fff;
      background-clip: padding-box;
      border: 1px solid #ced4da;
      border-radius: 0.25rem;
      transition: all 0.3s ease-in-out;
    }
    .input-auth:focus {
      border-color: #72081f;
      outline: none;
      box-shadow: 0 0 5px 2px rgba(255, 106, 133, 0.5);
    }
    .input-autht:focus::placeholder {
      color: transparent;
    }
    /* Btn Style  */
    .btn-gorec {
      width: 250px;
      height: 50px;
      background-color: #9C0C27;
      color: #fff;
      border-radius: 50px
    }
    .btn-gorec:hover {
      background-color: #72081f;
      color: #fff;;
    }
    /* Line */
    .line {
      border: 0;
      border-top: 1px solid #72081f;
      margin: 1rem 0;
      width: 50%;
    }
    /* Redirection */
    .login-direction {
      color: #72081f;
      text-decoration: none;
    }
    @media (max-width: 991.98px) {
      .cascading-left {
        margin-left: 0px;
      }
      section {
        margin-top: 0px;
      }
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/dataTables.responsive.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/3.0.2/js/responsive.bootstrap5.min.js"></script>
  <script>
    $(document).ready(function(){
      $('#segmentosTable').DataTable({
        responsive: true,
        language: {
          search: "Buscar:",
          lengthMenu: "Mostrar _MENU_ registros por página",
          zeroRecords: "No se encontraron resultados",
          info: "Mostrando página _PAGE_ de _PAGES_",
          infoEmpty: "No hay registros disponibles",
          infoFiltered: "(filtrado de _MAX_ registros totales)",
          paginate: {
            first: "Primero",
            last: "Último",
            next: "Siguiente",
            previous: "Anterior"
          }
        }
      });
    });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/inversion/index.blade.php ENDPATH**/ ?>