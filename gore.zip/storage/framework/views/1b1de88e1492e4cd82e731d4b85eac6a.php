<form action="<?php echo e(route('segmento.destroy', $segmento->idSegmento)); ?>" method="POST">
  <?php echo e(method_field('delete')); ?>

  <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="ModalDelete<?php echo e($segmento->idSegmento); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title"><i class="fas fa-stream"></i> Eliminar Segmento</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center">
          ¿Estas seguro de borrar el segmento <b><?php echo e($segmento->nombreSegmento); ?></b>?
          <div class="row">
            <div class="col-12 pt-3 text-center">
              <button class="btn btn-primary mx-1" data-dismiss="modal"><i class="fas fa-undo-alt"></i>&nbsp;&nbsp; Volver</button>
              <button type="submit" class="btn btn-danger mx-1"><i class="fas fa-trash-alt"></i>&nbsp;&nbsp; Eliminar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/segmento/delete.blade.php ENDPATH**/ ?>