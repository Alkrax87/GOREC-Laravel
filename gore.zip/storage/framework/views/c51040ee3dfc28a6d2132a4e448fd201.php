<div class="modal fade text-left" id="ModalShow<?php echo e($inversion->idInversion); ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><i class="fas fa-eye"></i> Detalle Asignación</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <h2><?php echo e($inversion->nombreCortoInversion); ?></h2>
              <p><i class="fas fa-portrait"></i> <b>Responsable: </b><?php echo e($inversion->usuario->nombreUsuario . ' ' . $inversion->usuario->apellidoUsuario); ?></p>
              <h4><i class="fas fa-user-tie"></i> Profesionales</h4>
              <?php $__currentLoopData = $profesionales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card border-danger">
                  <div class="card-header bg-danger">
                    <b><i class="fas fa-user-tie"></i> <?php echo e($profesional->usuario->nombreUsuario . ' ' . $profesional->usuario->apellidoUsuario); ?></b>
                  </div>
                  <div class="card-body pb-0">
                    <div class="row">
                      <div class="col-6">
                        <b><i class="fas fa-user-graduate"></i> Profesiones</b>
                        <?php if($profesional->usuario->profesiones->isNotEmpty()): ?>
                          <ul>
                            <?php $__currentLoopData = $profesional->usuario->profesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="fw-normal"><?php echo e($profesion->nombreProfesion); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <?php endif; ?>
                      </div>
                      <div class="col-6">
                        <b><i class="fas fa-user-cog"></i> Especialidad:</b>
                        <?php if($profesional->usuario->especialidades->isNotEmpty()): ?>
                          <ul>
                            <?php $__currentLoopData = $profesional->usuario->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li class="fw-normal"><?php echo e($especialidad->nombreEspecialidad); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <?php endif; ?>
                      </div>
                    </div>
                    <hr class="mt-0">
                    <h5><i class="fas fa-users-cog"></i> Asistentes</h5>
                    <?php $__currentLoopData = $asistentes->where('idJefe', $profesional->usuario->idUsuario); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="card text-white bg-dark mb-3">
                        <div class="card-header"><i class="fas fa-users-cog"></i> <?php echo e($asistente->usuario->nombreUsuario . ' ' . $asistente->usuario->apellidoUsuario); ?></div>
                        <div class="card-body">
                          <div class="row">
                            <div class="col-6">
                              <b><i class="fas fa-user-graduate"></i> Profesiones</b>
                              <?php if($asistente->usuario->profesiones->isNotEmpty()): ?>
                                <ul>
                                  <?php $__currentLoopData = $asistente->usuario->profesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="fw-normal"><?php echo e($profesion->nombreProfesion); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                              <?php endif; ?>
                            </div>
                            <div class="col-6">
                              <b><i class="fas fa-user-cog"></i> Especialidad:</b>
                              <?php if($asistente->usuario->especialidades->isNotEmpty()): ?>
                                <ul>
                                  <?php $__currentLoopData = $asistente->usuario->especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="fw-normal"><?php echo e($especialidad->nombreEspecialidad); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-12 py-2 text-center">
              <button class="btn btn-primary" data-dismiss="modal"><i class="fas fa-undo-alt"></i>&nbsp;&nbsp; Volver</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\BUTTOWSKY\Desktop\GORE\GOREC-Laravel\resources\views/asignaciones/show.blade.php ENDPATH**/ ?>